# -*- coding: utf-8 -*-
"""
Created on Sat Feb 20 03:19:03 2021

@author: dakin

Tyler Dakin

Lawn service estimation application-revisited

Due- 2/21/2021

This application asks the user for the dimensions of a yard and then asks
if they have more yards they would like to enter. it then calculates the 
prices it will cost for a  single and full season of applications with
a discount.


"""
sum = 0

# This is the origin yard where things begin.
width = int(input("Please enter the width of the yard: "))
length = int(input("Please enter the length of the yard: "))

if width <= 0:
    print("----------------------------------------------------------------------------")
    print("Error---The width you have entered is invalid, please enter another number.")
    width = int(input("Please enter the width of the yard: "))
if length <= 0:
    print("----------------------------------------------------------------------------")
    print("Error---The length you have entered is invalid, please enter another number.")
    length = int(input("Please enter the width of the yard: "))
    
if width or length > 0:
    area = width * length
    print("----------------------------------------")
    print("The area of region 1 is", area, "sq. ft")
    sum = sum + area

# These are the yards that are then added on to the orginal.
while width > 0 or length > 0:
    newvalue = input(" would you like to enter another region? ")
    if newvalue == "yes" or newvalue == "Yes": 
        width2 = int(input("Enter the new width: "))
        length2 = int(input("Enter the new length: "))
        value = length2 * width2
        sum = sum + value
        total = sum
        print("-------------------------------------------------")
        print(" The area of the new region is", value,"sq. ft")
        cost1 = round(total / 10890 * 65, 2)
        discount = round(cost1 * 4 * .10, 2)
        cost2 = round(cost1 * 4 - discount, 2)
    if newvalue == "no" or newvalue == "No":
        print("                                                                                   ")
        print("The estimated cost of a lawn treatment for an area of", total,"Sq. ft")
        print("---------------------------------------------------------------------")
        print("One application of fertilizer: $", cost1)
        print("A full season of applications of fertilizer: $", cost2)
        print("You save $",discount,"by choosing a season of applications.")
        break
        
        
        
        
        
        